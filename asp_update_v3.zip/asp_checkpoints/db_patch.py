p = "db.py"
s = open(p).read()
if "pipeline_steps" in s:
    print("db.py already patched"); raise SystemExit

# 1) bounded connect time (so a down Postgres fails fast instead of hanging a run) + create the new table
old = "        _pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10)\n"
assert old in s, "create_pool line not found"
s = s.replace(old, "        _pool = await asyncpg.create_pool(\n            DATABASE_URL, min_size=1, max_size=10, timeout=5, command_timeout=30\n        )\n", 1)
old = "            await conn.execute(_SCHEMA)\n"
assert old in s, "schema execute line not found"
s = s.replace(old, "            await conn.execute(_SCHEMA)\n            await conn.execute(_PIPELINE_SCHEMA)\n", 1)

# 2) pipeline checkpoint table + helpers
s = s.rstrip("\n") + '''


# ════════════════════════════════════════════════════════════════
#  Pipeline checkpoints (crash recovery)
# ════════════════════════════════════════════════════════════════
#
# One row per (case_id, step). `step` is one of: meta, forensic, rag,
# profiler, final. `status` is 'partial' (text streamed so far, saved
# periodically and on failure) or 'complete'. A finished step is never
# overwritten by a late partial save (see save_step's WHERE clause).

_PIPELINE_SCHEMA = """
CREATE TABLE IF NOT EXISTS pipeline_steps (
    case_id     TEXT NOT NULL,
    step        TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('partial', 'complete')),
    content     TEXT NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (case_id, step)
);
"""


async def save_step(case_id: str, step: str, content: str, status: str) -> bool:
    """Upsert one step. Returns False if skipped (a partial never overwrites a complete)."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchval(
            """
            INSERT INTO pipeline_steps (case_id, step, status, content, updated_at)
            VALUES ($1, $2, $3, $4, now())
            ON CONFLICT (case_id, step) DO UPDATE
               SET status = EXCLUDED.status,
                   content = EXCLUDED.content,
                   updated_at = now()
             WHERE NOT (pipeline_steps.status = 'complete' AND EXCLUDED.status = 'partial')
            RETURNING 1
            """,
            case_id, step, status, content,
        )
    return row is not None


async def load_steps(case_id: str) -> dict[str, dict[str, Any]]:
    """All saved steps for a case: {step: {status, content, updated_at}}."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT step, status, content, updated_at FROM pipeline_steps WHERE case_id = $1",
            case_id,
        )
    return {
        r["step"]: {
            "status": r["status"],
            "content": r["content"],
            "updated_at": r["updated_at"].isoformat(),
        }
        for r in rows
    }


async def delete_case(case_id: str) -> None:
    """Forget a case entirely (used by 'Start fresh')."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM pipeline_steps WHERE case_id = $1", case_id)
        await conn.execute("DELETE FROM agent_results WHERE task_id = $1", case_id)


async def delete_steps(case_id: str, steps: list[str]) -> None:
    """Drop specific steps (e.g. downstream results made stale by a regenerated Forensic report)."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "DELETE FROM pipeline_steps WHERE case_id = $1 AND step = ANY($2::text[])",
            case_id, steps,
        )


async def list_cases(limit: int = 25) -> list[dict[str, Any]]:
    """Most recently updated cases first, with a compact step summary."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT case_id,
                   max(updated_at) AS updated_at,
                   string_agg(step || ':' || status, ',' ORDER BY step) AS steps,
                   max(content) FILTER (WHERE step = 'meta') AS meta
              FROM pipeline_steps
             GROUP BY case_id
             ORDER BY max(updated_at) DESC
             LIMIT $1
            """,
            limit,
        )
    return [
        {
            "case_id": r["case_id"],
            "updated_at": r["updated_at"].isoformat(),
            "steps": r["steps"],
            "meta": r["meta"],
        }
        for r in rows
    ]
'''
open(p, "w").write(s + "\n")
print("db.py patched")
