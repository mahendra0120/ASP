p = "main.py"
s = open(p).read()
if "pipeline_state as pstate" in s:
    print("main.py already patched"); raise SystemExit

# ── 1) import ─────────────────────────────────────────────────────────
old = "import gradio as gr\n"
assert old in s, "gradio import not found"
s = s.replace(old, old + "import pipeline_state as pstate\n", 1)

# ── 2) orchestrator: checkpointed run_pipeline_async + targeted agent restart ──
A = r'''def _start_single_agent(name: str) -> str:
    """Start ONLY the named agent server (crash recovery). launch_servers() would
    relaunch all three and orphan the ones that are still healthy."""
    global profiler_proc, forensic_proc
    script, port, logname = {
        "Forensic": ("A2A_forensic_server.py", FORENSIC_PORT, "forensic_server.log"),
        "Profiler": ("A2A_profiler_server.py", PROFILER_PORT, "profiler_server.log"),
    }[name]
    path = REPO_ROOT / script
    if not path.exists():
        return f"❌ {name}: missing {script}"
    log_dir = REPO_ROOT / "server_logs"
    log_dir.mkdir(exist_ok=True)
    logfile = log_dir / logname
    if logfile.exists():                      # keep the dead server's log (it holds the crash trace)
        os.replace(logfile, logfile.with_name(logfile.name + ".prev"))
    proc = subprocess.Popen(
        [sys.executable, str(path)],
        stdout=open(logfile, "w"), stderr=subprocess.STDOUT, cwd=str(REPO_ROOT),
    )
    if name == "Forensic":
        forensic_proc = proc
    else:
        profiler_proc = proc
    if "_watch_server_exits" in globals():
        _watch_server_exits({name: proc}, log_dir)
    ready = _wait_for_ports({name: port}, timeout=SERVER_READY_TIMEOUT)
    return f"✅ {name}:{port} restarted" if ready.get(name) else f"⚠️ {name}:{port} did not come up (see {logfile})"


async def _ensure_agent_up(name: str) -> None:
    port = FORENSIC_PORT if name == "Forensic" else PROFILER_PORT
    if _port_open(port):
        return
    log.warning(f"{name} agent server is not listening on :{port} - restarting just that server")
    log.info(await asyncio.to_thread(_start_single_agent, name))


async def run_pipeline_async(image_urls: list[str], extra_context: str, case_id: str, resume_mode: str = "continue"):
    """
    Forensic -> (RAG || Profiler) with every step checkpointed to Postgres
    (see pipeline_state.py). resume_mode:
      "continue" - reuse finished steps, continue partial reports where they stopped
      "asis"     - reuse finished steps, accept partial reports as they are
      "fresh"    - discard saved progress for this case and start over
    """
    forensic_text = ""
    profiler_text = ""
    rag_text = ""
    final_text = ""
    store = pstate.CaseStore(case_id)

    def S(msg: str) -> str:
        return msg + store.status_suffix()

    try:
        task_id = case_id

        forensic_message = FORENSIC_USER_MESSAGE
        if extra_context and extra_context.strip():
            forensic_message += f"\n\nAdditional Context:\n{extra_context}"

        saved: dict = {}
        if resume_mode == "fresh":
            await store.delete_all()
        else:
            saved = await store.load_all()
        await store.save("meta", pstate.meta_json(image_urls, extra_context), "complete")

        summary = ", ".join(f"{k}={v['status']}" for k, v in saved.items() if k != "meta")
        if summary:
            log.info(f"[case {case_id}] resuming with saved progress: {summary} (mode={resume_mode})")
        yield forensic_text, profiler_text, rag_text, final_text, S(
            f"♻️ Case {case_id}: found saved progress ({summary}) - resuming..." if summary
            else f"⏳ Case {case_id}: starting..."
        )

        # 1) Forensic. Finished -> reused; partial -> continued (or accepted as-is);
        #    otherwise generated. Streams the agent's real output, checkpointed as it goes.
        sf = saved.get("forensic")
        forensic_done = False
        prefix = ""
        if sf and sf["status"] == "complete":
            forensic_text, forensic_done = sf["content"], True
            yield forensic_text, profiler_text, rag_text, final_text, S(
                "♻️ Forensic report restored from the database - skipping that step"
            )
        elif sf and sf["status"] == "partial":
            if resume_mode == "asis":
                forensic_text, forensic_done = sf["content"], True
                await store.save("forensic", forensic_text, "complete")
                await store.invalidate(["rag", "profiler", "final"])
                yield forensic_text, profiler_text, rag_text, final_text, S(
                    "⏭ Using the saved partial Forensic report as-is"
                )
            else:
                prefix = pstate.trim_partial(sf["content"])
                forensic_text = prefix
        forensic_reused = bool(sf and sf["status"] == "complete")

        if not forensic_done:
            # Anything computed from an older Forensic result is now stale.
            await store.invalidate(["rag", "profiler", "final"])
            if not _port_open(FORENSIC_PORT):
                yield forensic_text, profiler_text, rag_text, final_text, S(
                    "🔧 Forensic server is down - restarting it (the model reloads on first use)..."
                )
                await _ensure_agent_up("Forensic")
            prompt = forensic_message
            if prefix:
                prompt += pstate.continuation_block("forensic report", prefix)
            running = "⏳ Continuing the interrupted Forensic report..." if prefix else "⏳ Running Forensic agent..."
            yield forensic_text, profiler_text, rag_text, final_text, S(running)
            async for forensic_text in pstate.checkpointed(
                step_forensic_stream(image_urls, prompt), store, "forensic", prefix=prefix
            ):
                yield forensic_text, profiler_text, rag_text, final_text, S(running)
        forensic_data = forensic_text
        yield forensic_text, profiler_text, rag_text, final_text, S(
            "⏳ Forensic agent complete - running Profiler agent and RAG grounding concurrently..."
        )

        # 2) RAG and the Profiler run AT THE SAME TIME off the finished Forensic report.
        #    Saved RAG/Profiler results are only reused if the Forensic report they were
        #    built from was itself reused unchanged.
        saved_rag = saved.get("rag") if forensic_reused else None
        sp = saved.get("profiler") if forensic_reused else None

        async def _rag_step():
            if saved_rag and saved_rag["status"] == "complete":
                try:
                    return pstate.loads(saved_rag["content"])
                except ValueError:
                    pass
            data = await step_forensic_rag(task_id, forensic_data)
            await store.save("rag", pstate.dumps(data), "complete")
            return data

        async def _saved_text(t: str):
            yield t

        profiler_source = None
        p_prefix = ""
        if sp and sp["status"] == "complete":
            profiler_source = _saved_text(sp["content"])
        elif sp and sp["status"] == "partial":
            if resume_mode == "asis":
                await store.save("profiler", sp["content"], "complete")
                profiler_source = _saved_text(sp["content"])
            else:
                p_prefix = pstate.trim_partial(sp["content"])
                profiler_text = p_prefix
        if profiler_source is None:
            if not _port_open(PROFILER_PORT):
                yield forensic_text, profiler_text, rag_text, final_text, S(
                    "🔧 Profiler server is down - restarting it (the model reloads on first use)..."
                )
                await _ensure_agent_up("Profiler")
            cont = pstate.continuation_block("behavioral profile", p_prefix) if p_prefix else None
            profiler_source = pstate.checkpointed(
                step_profiler_stream(image_urls, forensic_data, None, continuation=cont),
                store, "profiler", prefix=p_prefix,
            )

        rag_task_gen = _one_shot_stream(_rag_step())
        async with aclosing(_run_concurrently({"rag": rag_task_gen, "profiler": profiler_source})) as stream:
            async for latest, errors in stream:
                if errors:
                    raise RuntimeError(
                        "; ".join(f"{k} step: {e}" for k, e in errors.items())
                    )
                if latest["rag"] != "":
                    rag_data = latest["rag"]
                    rag_text = (
                        format_rag_section(rag_data) if rag_data["triggered"]
                        else "_No evidence-of-trauma language detected in the Forensic report - RAG pipeline not triggered._"
                    )
                if latest["profiler"] != "":
                    profiler_text = latest["profiler"]
                yield forensic_text, profiler_text, rag_text, final_text, S(
                    "⏳ Running Profiler agent and RAG grounding concurrently..."
                )
        profiler_data = profiler_text
        yield forensic_text, profiler_text, rag_text, final_text, S("⏳ Finalizing report...")

        log.info(f"Combining Forensic + RAG + Profiler results into final profiling report (task_id={task_id})")
        sections = [
            f"# Case {task_id}",
            f"## Forensic Analysis\n\n{forensic_data}",
        ]
        if rag_data["triggered"]:
            sections.append(f"## Forensic Knowledge Base Grounding (RAG)\n\n{rag_text}")
        sections.append(f"## Profiler Analysis\n\n{profiler_data}")
        final_markdown = "\n\n".join(sections) + "\n"

        Path("pipeline_result.md").write_text(final_markdown)
        await store.save("final", final_markdown, "complete")

        yield forensic_text, profiler_text, rag_text, final_markdown, S("✅ Pipeline completed successfully!")
    except Exception as e:
        # Keep every panel's text (the old code overwrote ALL panels with the error,
        # wiping a finished Forensic report). Progress is already in Postgres.
        await asyncio.sleep(0.3)   # cancelled tasks (e.g. a Profiler stopped by a RAG error) finish flushing their partial output
        hint = (
            f" - progress is saved as case {case_id}; press ▶ Run Pipeline again "
            f"(resume mode) to continue from where it stopped."
            if store.ok else " - the database is unavailable, so this progress was NOT saved."
        )
        yield forensic_text, profiler_text, rag_text, final_text, f"❌ {e}{hint}"


'''
a0 = s.index("async def run_pipeline_async(")
a1 = s.index("async def _one_shot_stream(")
s = s[:a0] + A + s[a1:]

# ── 3) run_pipeline (+ saved-case support) and the dropdown helper ───────
B = r'''async def run_pipeline(images, image_url, extra_context, resume_mode="continue", saved_case=None):
    image_urls: list[str] = []

    if saved_case:
        # Resume a saved case without re-uploading: images + context come from the database.
        meta = await pstate.CaseStore(saved_case).load_meta()
        if not meta or not meta.get("image_urls"):
            yield tuple([f"❌ Saved case {saved_case} was not found in the database."] * 5)
            return
        image_urls = list(meta["image_urls"])
        extra_context = meta.get("extra_context", "")
        missing = [u for u in image_urls if not pstate.image_available(u)]
        if missing:
            yield tuple([
                f"❌ Saved case {saved_case}: {len(missing)} image file(s) no longer exist on disk. "
                f"Re-upload the original images with the same context and run again - the case id "
                f"will match and your saved progress will be used."
            ] * 5)
            return
        case_id = saved_case
    else:
        # Prioritize uploaded images over URL; combine if both given.
        if images:
            if len(images) > MAX_IMAGES:
                yield tuple([f"❌ Too many images ({len(images)}). Max is {MAX_IMAGES}."] * 5)
                return
            image_urls.extend(save_uploaded_images(images))

        if image_url and image_url.strip():
            image_urls.append(image_url.strip())

        if not image_urls:
            yield tuple(["❌ Please provide at least one image upload or image URL"] * 5)
            return

        if len(image_urls) > MAX_IMAGES:
            yield tuple([f"❌ Too many images ({len(image_urls)}). Max is {MAX_IMAGES}."] * 5)
            return
        case_id = pstate.case_id_for(image_urls, extra_context)

    log.info(f"Pipeline starting with {len(image_urls)} image(s) (case {case_id}, mode={resume_mode})")

    try:
        async for update in run_pipeline_async(image_urls, extra_context, case_id, resume_mode or "continue"):
            yield update
    except Exception as e:
        error = f"❌ Critical error: {e}"
        yield tuple([error] * 5)


async def list_cases_for_ui():
    rows = await pstate.list_cases_safe()
    return gr.Dropdown(choices=[(pstate.describe_case(r), r["case_id"]) for r in rows], value=None)


'''
b0 = s.index("async def run_pipeline(images, image_url, extra_context):")
b1 = s.index("async def step_forensic_stream(")
s = s[:b0] + B + s[b1:]

# ── 4) Profiler step accepts an optional continuation block ──────────────
old = "async def step_profiler_stream(image_urls: list[str], forensic_report: str, rag_data: dict | None = None):"
assert old in s, "step_profiler_stream signature not found"
s = s.replace(old, "async def step_profiler_stream(image_urls: list[str], forensic_report: str, rag_data: dict | None = None, continuation: str | None = None):", 1)
old = ("    image_parts = [\n        ImagePart(url=url, media_type=guess_image_media_type(url)) for url in image_urls\n    ]\n"
       "    start = time.monotonic()\n    text = \"\"\n    try:\n        async for delta in PROFILER_AGENT.stream_task(")
assert old in s, "profiler stream anchor not found"
s = s.replace(old, "    if continuation:\n        combined_prompt += continuation\n" + old, 1)

# ── 5) UI: resume controls + new click wiring ───────────────────────────
old = '    run_btn = gr.Button("▶ Run Pipeline", variant="primary", size="large")\n'
assert old in s, "run button not found"
s = s.replace(old, old + r'''
    with gr.Row():
        resume_mode = gr.Radio(
            choices=[
                ("♻️ Resume - continue partial reports", "continue"),
                ("⏭ Resume - use partial reports as-is", "asis"),
                ("🆕 Start fresh (discard saved progress)", "fresh"),
            ],
            value="continue",
            label="Progress is saved to Postgres. If this exact case (same images + context) was run before:",
        )
        saved_case = gr.Dropdown(
            choices=[], value=None, allow_custom_value=True,
            label="...or resume a saved case (overrides the inputs above)",
        )
        refresh_cases = gr.Button("🔄 Refresh saved cases")
''', 1)
old = ("    run_btn.click(\n        fn=run_pipeline,\n        inputs=[image_input, url_input, extra_context],\n"
       "        outputs=[forensic_out, profiler_out, rag_out, full_out, status_out],\n    )\n")
assert old in s, "run_btn.click block not found"
s = s.replace(old, ("    run_btn.click(\n        fn=run_pipeline,\n        inputs=[image_input, url_input, extra_context, resume_mode, saved_case],\n"
                    "        outputs=[forensic_out, profiler_out, rag_out, full_out, status_out],\n    ).then(fn=list_cases_for_ui, outputs=saved_case)\n"
                    "    refresh_cases.click(fn=list_cases_for_ui, outputs=saved_case)\n"
                    "    demo.load(fn=list_cases_for_ui, outputs=saved_case)\n"), 1)

open(p, "w").write(s)
print("main.py patched")
