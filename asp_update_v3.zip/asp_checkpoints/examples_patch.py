# Adds the "Examples - images you uploaded before" gallery to the Gradio UI.
p = "main.py"
s = open(p).read()
assert "pipeline_state as pstate" in s, "checkpoint layer (main_patch) must be installed first"
if "example_gallery" in s:
    print("main.py: examples gallery already present"); raise SystemExit

# 1) import
old = "import pipeline_state as pstate\n"
assert s.count(old) == 1, "pstate import anchor not found"
s = s.replace(old, old + "import example_images\n", 1)

# 2) handlers (placed before list_cases_for_ui)
old = "async def list_cases_for_ui():\n"
assert s.count(old) == 1, "list_cases_for_ui anchor not found"
HANDLERS = r'''def refresh_examples():
    """Thumbnails of photos uploaded before (temp_uploads/), newest first, duplicates removed.
    Set SHOW_UPLOAD_EXAMPLES=0 to hide them (they are real case photos)."""
    if os.getenv("SHOW_UPLOAD_EXAMPLES", "1") == "0":
        return [], []
    items = example_images.list_example_images(TEMP_IMAGE_DIR, limit=24)
    return [(it["path"], it["name"]) for it in items], [it["path"] for it in items]


def add_example(current_files, example_list, evt: gr.SelectData):
    """Clicking a thumbnail adds that photo to the upload box (never twice, never beyond MAX_IMAGES)."""
    files = example_images.normalize_paths(current_files)
    try:
        chosen = (example_list or [])[int(evt.index)]
    except (TypeError, ValueError, IndexError):
        return files or None
    return example_images.add_unique(files, [chosen], MAX_IMAGES, warn=gr.Warning) or None


def add_all_examples(current_files, example_list):
    files = example_images.normalize_paths(current_files)
    return example_images.add_unique(files, list(example_list or []), MAX_IMAGES, warn=gr.Warning) or None


'''
s = s.replace(old, HANDLERS + old, 1)

# 3) the section itself, right under "Additional Context"
old = ('                placeholder="This photo was taken in a forest during autumn. The person is a biologist studying mushrooms.",\n'
       '                lines=3\n            )\n')
assert s.count(old) == 1, "extra_context anchor not found"
s = s.replace(old, old + r'''
            with gr.Accordion("🖼 Examples - photos you uploaded before", open=True):
                gr.Markdown(
                    "Click a thumbnail to add it to **Upload Photos** above. The same photo is never added twice. "
                    "Pick the same photos in the same order as before to find that case's saved progress."
                )
                example_gallery = gr.Gallery(
                    show_label=False, columns=6, height=220, object_fit="cover",
                    allow_preview=False, interactive=False,
                )
                example_paths = gr.State([])
                with gr.Row():
                    add_all_btn = gr.Button("➕ Add all shown (up to 15)")
                    refresh_examples_btn = gr.Button("🔄 Refresh examples")
''', 1)

# 4) wiring
old = "    demo.load(fn=list_cases_for_ui, outputs=saved_case)\n"
assert s.count(old) == 1, "demo.load anchor not found"
s = s.replace(old, old + '''    demo.load(fn=refresh_examples, outputs=[example_gallery, example_paths])
    refresh_examples_btn.click(fn=refresh_examples, outputs=[example_gallery, example_paths])
    example_gallery.select(fn=add_example, inputs=[image_input, example_paths], outputs=image_input)
    add_all_btn.click(fn=add_all_examples, inputs=[image_input, example_paths], outputs=image_input)
''', 1)

# 5) refresh the gallery after every run (a run saves new copies of the photos)
old = ").then(fn=list_cases_for_ui, outputs=saved_case)\n"
assert s.count(old) == 1, "run chain anchor not found"
s = s.replace(old, ").then(fn=list_cases_for_ui, outputs=saved_case).then(\n"
                   "        fn=refresh_examples, outputs=[example_gallery, example_paths]\n    )\n", 1)
open(p, "w").write(s)
print("main.py: examples gallery added")
