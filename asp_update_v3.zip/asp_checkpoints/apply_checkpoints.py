#!/usr/bin/env python3
"""
Install / upgrade the ASP update (Postgres crash recovery, delete controls,
examples gallery, environment defaults).

Run from the repo root (the folder containing main.py):
    python3 /path/to/apply_checkpoints.py

Works from any starting point: it only applies what is missing.
  1. Postgres checkpoints + resume       (pipeline_state.py, db.py, main.py)
  2. "Manage saved progress" delete UI   (db.py, main.py)
  3. "Examples" gallery of earlier uploads (example_images.py, main.py)
  4. env_defaults.py: HF_HOME / HF_HUB_OFFLINE / agent ports work without manual exports
     (main.py, both A2A servers, model_utils.py, start.sh)

All-or-nothing: if any step fails, every touched file is restored byte-for-byte.
Persistent copies of the originals are kept as <file>.before_checkpoints[.timestamp].

Rollback: copy each *.before_checkpoints (use the OLDEST one) back over its file and
delete pipeline_state.py, env_defaults.py, example_images.py.
"""
import py_compile
import runpy
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()

NEW_MODULES = ("pipeline_state.py", "env_defaults.py", "example_images.py")
PATCHED = ("main.py", "db.py", "A2A_forensic_server.py", "A2A_profiler_server.py", "qwen_agents/model_utils.py", "start.sh")
SCRIPTS = ("db_patch.py", "main_patch.py", "memory_patch.py", "examples_patch.py", "env_patch.py")

for need in ("main.py", "db.py", "A2A_forensic_server.py", "A2A_profiler_server.py", "qwen_agents/model_utils.py", "start.sh"):
    if not (ROOT / need).exists():
        sys.exit(f"Run this from the ASP repo root: {need} not found in {ROOT}")
for need in NEW_MODULES + SCRIPTS:
    if not (HERE / need).exists():
        sys.exit(f"Missing {need} next to apply_checkpoints.py (expected in {HERE})")

main_text = (ROOT / "main.py").read_text()
db_text = (ROOT / "db.py").read_text()
has_checkpoints = "pipeline_state as pstate" in main_text
has_memory = has_checkpoints and "memory_status" in main_text and "delete_cases_older_than" in db_text
has_examples = "example_gallery" in main_text
has_env = "import env_defaults" in main_text

plan = []
if not has_checkpoints:
    plan += ["db_patch.py", "main_patch.py"]
if not has_memory:
    plan += ["memory_patch.py"]
if not has_examples:
    plan += ["examples_patch.py"]
if not has_env:
    plan += ["env_patch.py"]
if not plan:
    print("Already fully installed - nothing to do."); sys.exit(0)

# Exact bytes right now: used to undo everything if any step fails.
TOUCHED = PATCHED + NEW_MODULES
ORIGINALS = {f: ((ROOT / f).read_bytes() if (ROOT / f).exists() else None) for f in TOUCHED}

# Persistent backups for manual rollback (never overwrite an older backup).
stamp = time.strftime("%Y%m%d-%H%M%S")
for f in PATCHED:
    backup = ROOT / (f + ".before_checkpoints")
    if backup.exists():
        backup = ROOT / (f + f".before_checkpoints.{stamp}")
    backup.write_bytes(ORIGINALS[f])

for mod in NEW_MODULES:
    shutil.copy2(HERE / mod, ROOT / mod)
print("Plan:", " -> ".join(plan))
try:
    for patch in plan:
        try:
            runpy.run_path(str(HERE / patch), run_name="__main__")
        except SystemExit as e:                      # patch scripts use SystemExit for "already patched"
            if e.code not in (None, 0):
                raise
    for f in TOUCHED:
        if f.endswith(".py"):
            py_compile.compile(str(ROOT / f), doraise=True)
except BaseException as e:                           # noqa: BLE001 - restore on ANY failure
    for f, data in ORIGINALS.items():
        if data is None:
            (ROOT / f).unlink(missing_ok=True)
        else:
            (ROOT / f).write_bytes(data)
    sys.exit(f"\nINSTALL FAILED - originals restored, nothing changed.\nReason: {type(e).__name__}: {e}")

print("\nInstalled. Restart the app:  pkill -f 'main\\.py'; bash start.sh")
