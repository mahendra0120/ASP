# Adds the "delete saved progress" feature on top of the checkpoint layer.
import re

# ───────────── db.py ─────────────
p = "db.py"
s = open(p).read()
assert "pipeline_steps" in s, "checkpoint layer (db_patch) must be installed first"
if "delete_cases_older_than" not in s:
    s = s.rstrip("\n") + '''


# ── memory management ───────────────────────────────────────────
# These only ever touch pipeline cases (and their published copies in
# agent_results). Rows other MCP clients wrote to agent_results under
# their own task ids are left alone.

async def forget_case(case_id: str) -> int:
    """Delete one case. Returns how many saved steps it had."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            n = await conn.fetchval(
                "WITH d AS (DELETE FROM pipeline_steps WHERE case_id = $1 RETURNING 1) SELECT count(*) FROM d",
                case_id,
            )
            await conn.execute("DELETE FROM agent_results WHERE task_id = $1", case_id)
    return int(n or 0)


async def delete_cases_older_than(days: int) -> int:
    """Delete every case whose most recent activity is older than `days` days. Returns cases removed."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            ids = [
                r["case_id"]
                for r in await conn.fetch(
                    """
                    SELECT case_id FROM pipeline_steps
                     GROUP BY case_id
                    HAVING max(updated_at) < now() - make_interval(days => $1)
                    """,
                    int(days),
                )
            ]
            if ids:
                await conn.execute("DELETE FROM pipeline_steps WHERE case_id = ANY($1::text[])", ids)
                await conn.execute("DELETE FROM agent_results WHERE task_id = ANY($1::text[])", ids)
    return len(ids)


async def delete_all_cases() -> int:
    """Delete every saved pipeline case. Returns cases removed."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            ids = [r["case_id"] for r in await conn.fetch("SELECT DISTINCT case_id FROM pipeline_steps")]
            if ids:
                await conn.execute("DELETE FROM pipeline_steps WHERE case_id = ANY($1::text[])", ids)
                await conn.execute("DELETE FROM agent_results WHERE task_id = ANY($1::text[])", ids)
    return len(ids)
'''
    open(p, "w").write(s + "\n")
    print("db.py: memory functions added")

# ───────────── main.py ─────────────
p = "main.py"
s = open(p).read()
assert "pipeline_state as pstate" in s, "checkpoint layer (main_patch) must be installed first"
if "memory_status" in s:
    print("main.py: memory controls already present"); raise SystemExit

# handlers, placed just before list_cases_for_ui
old = "async def list_cases_for_ui():\n"
assert s.count(old) == 1, "list_cases_for_ui anchor not found"
HANDLERS = r'''async def delete_selected_case_ui(confirm, case_id):
    if not confirm:
        return "⚠️ Tick the confirmation box first - nothing was deleted.", await list_cases_for_ui(), gr.Checkbox(value=False)
    if not case_id:
        return "⚠️ Pick a saved case in the dropdown above first.", await list_cases_for_ui(), gr.Checkbox(value=False)
    ok, res = await pstate.run_safe(pstate.db.forget_case(str(case_id)))
    msg = (f"🗑 Deleted case {case_id} ({res} saved step(s))." if res else f"Nothing was saved under case {case_id}.") if ok \
        else f"❌ Database unavailable - nothing deleted: {res}"
    log.info(f"[memory] {msg}")
    return msg, await list_cases_for_ui(), gr.Checkbox(value=False)


async def delete_old_cases_ui(confirm, days):
    if not confirm:
        return "⚠️ Tick the confirmation box first - nothing was deleted.", await list_cases_for_ui(), gr.Checkbox(value=False)
    try:
        days = int(days)
        if days < 1:
            raise ValueError
    except (TypeError, ValueError):
        return "⚠️ Enter a whole number of days (1 or more).", await list_cases_for_ui(), gr.Checkbox(value=False)
    ok, res = await pstate.run_safe(pstate.db.delete_cases_older_than(days))
    msg = f"🧹 Deleted {res} case(s) with no activity in the last {days} day(s)." if ok \
        else f"❌ Database unavailable - nothing deleted: {res}"
    log.info(f"[memory] {msg}")
    return msg, await list_cases_for_ui(), gr.Checkbox(value=False)


async def delete_all_cases_ui(confirm):
    if not confirm:
        return "⚠️ Tick the confirmation box first - nothing was deleted.", await list_cases_for_ui(), gr.Checkbox(value=False)
    ok, res = await pstate.run_safe(pstate.db.delete_all_cases())
    msg = f"🗑 Deleted all {res} saved case(s)." if ok else f"❌ Database unavailable - nothing deleted: {res}"
    log.info(f"[memory] {msg}")
    return msg, await list_cases_for_ui(), gr.Checkbox(value=False)


'''
s = s.replace(old, HANDLERS + old, 1)

# UI accordion, right after the resume row
old = '        refresh_cases = gr.Button("🔄 Refresh saved cases")\n'
assert s.count(old) == 1, "refresh button anchor not found"
s = s.replace(old, old + r'''
    with gr.Accordion("🗑 Manage saved progress (Postgres memory)", open=False):
        gr.Markdown(
            "Saved cases accumulate in Postgres until you delete them. Deleting is **permanent**: "
            "tick the box, then press one button. Image files in `temp_uploads/` are not touched. "
            "Avoid deleting a case while it is still running."
        )
        delete_confirm = gr.Checkbox(label="I understand this permanently deletes saved progress", value=False)
        with gr.Row():
            delete_case_btn = gr.Button("🗑 Delete the case selected above")
            older_days = gr.Number(label="Older than (days)", value=7, minimum=1, precision=0)
            delete_old_btn = gr.Button("🧹 Delete cases older than N days")
            delete_all_btn = gr.Button("⚠️ Delete ALL saved cases", variant="stop")
        memory_status = gr.Textbox(label="Result", interactive=False)
''', 1)

# event wiring
old = "    demo.load(fn=list_cases_for_ui, outputs=saved_case)\n"
assert s.count(old) == 1, "demo.load anchor not found"
s = s.replace(old, old + '''    delete_case_btn.click(fn=delete_selected_case_ui, inputs=[delete_confirm, saved_case],
                          outputs=[memory_status, saved_case, delete_confirm])
    delete_old_btn.click(fn=delete_old_cases_ui, inputs=[delete_confirm, older_days],
                         outputs=[memory_status, saved_case, delete_confirm])
    delete_all_btn.click(fn=delete_all_cases_ui, inputs=[delete_confirm],
                         outputs=[memory_status, saved_case, delete_confirm])
''', 1)
open(p, "w").write(s)
print("main.py: memory controls added")
