# Makes HF_HOME / HF_HUB_OFFLINE / agent ports effective no matter how a process is started.
import ast
from pathlib import Path


def insert_after_docstring(path: str, text: str) -> bool:
    s = Path(path).read_text()
    if "env_defaults" in s:
        return False
    tree = ast.parse(s)
    lines = s.splitlines(keepends=True)
    idx = 0
    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(getattr(tree.body[0], "value", None), ast.Constant) \
            and isinstance(tree.body[0].value.value, str):
        idx = tree.body[0].end_lineno
    for node in tree.body:                                   # __future__ imports must stay first
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            idx = max(idx, node.end_lineno)
    if idx == 0 and lines and lines[0].startswith("#!"):
        idx = 1
    lines.insert(idx, text if text.endswith("\n") else text + "\n")
    Path(path).write_text("".join(lines))
    return True


ENTRY = "import env_defaults  # noqa: F401  (HF_HOME / HF_HUB_OFFLINE / ports; must run before huggingface_hub is imported)"
for f in ("main.py", "A2A_forensic_server.py", "A2A_profiler_server.py"):
    print(f"{f}:", "env_defaults import added" if insert_after_docstring(f, ENTRY) else "already present")

# model_utils: also self-sufficient when imported by a script that did not apply the defaults
f = "qwen_agents/model_utils.py"
if "env_defaults" not in Path(f).read_text():
    insert_after_docstring(f, "try:  # apply the runtime defaults even if the caller did not\n    import env_defaults  # noqa: F401\nexcept ImportError:\n    pass")
    s = Path(f).read_text()
    old = 'hf_home = os.getenv("HF_HOME")\nif not hf_home:\n    raise RuntimeError("HF_HOME is not set")\n'
    assert old in s, "HF_HOME check in model_utils.py not found"
    s = s.replace(old, 'hf_home = os.getenv("HF_HOME") or "/workspace/hf_cache"\nos.environ["HF_HOME"] = hf_home\n', 1)
    Path(f).write_text(s)
    print(f"{f}: env_defaults import added; 'HF_HOME is not set' crash removed")
else:
    print(f"{f}: already present")

# start.sh: show the values the Python programs will really use
f = "start.sh"
s = Path(f).read_text()
if "env_defaults.py" not in s:
    old = 'echo ">> Starting ASP (Gradio on 0.0.0.0:7860)..."\n'
    assert old in s, "start.sh launch line not found"
    s = s.replace(old, 'echo ">> Effective runtime settings (what the Python programs will use):"\n'
                       'uv run python env_defaults.py || true\n\n' + old, 1)
    Path(f).write_text(s)
    print("start.sh: prints the effective settings before launching")
else:
    print("start.sh: already present")
