#!/usr/bin/env python3
"""
Install / upgrade the Postgres crash-recovery layer for the ASP repo.

Run from the repo root (the folder containing main.py):
    python3 /path/to/apply_checkpoints.py

Works from either starting point:
  * fresh repo            -> installs checkpoints + the "delete saved progress" controls
  * checkpoints installed -> adds only the "delete saved progress" controls

It is all-or-nothing: if any step fails, every file is restored byte-for-byte.
Persistent copies of the originals are kept as <file>.before_checkpoints[.timestamp].

Rollback:  cp main.py.before_checkpoints main.py; cp db.py.before_checkpoints db.py; rm pipeline_state.py
(if you ran this more than once, use the OLDEST backup; they are timestamped)
"""
import py_compile
import runpy
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()

for need in ("main.py", "db.py", "A2A_forensic_server.py"):
    if not (ROOT / need).exists():
        sys.exit(f"Run this from the ASP repo root: {need} not found in {ROOT}")
for need in ("pipeline_state.py", "db_patch.py", "main_patch.py", "memory_patch.py"):
    if not (HERE / need).exists():
        sys.exit(f"Missing {need} next to apply_checkpoints.py (expected in {HERE})")

main_text = (ROOT / "main.py").read_text()
db_text = (ROOT / "db.py").read_text()
has_checkpoints = "pipeline_state as pstate" in main_text
has_memory = has_checkpoints and "memory_status" in main_text and "delete_cases_older_than" in db_text
if has_memory:
    print("Already installed (checkpoints + delete controls) - nothing to do."); sys.exit(0)

# Exact bytes right now: used to undo everything if any step fails.
TOUCHED = ("main.py", "db.py", "pipeline_state.py")
ORIGINALS = {f: ((ROOT / f).read_bytes() if (ROOT / f).exists() else None) for f in TOUCHED}

# Persistent backups for manual rollback (never overwrite an older one).
stamp = time.strftime("%Y%m%d-%H%M%S")
for f in ("main.py", "db.py"):
    backup = ROOT / (f + ".before_checkpoints")
    if backup.exists():
        backup = ROOT / (f + f".before_checkpoints.{stamp}")
    backup.write_bytes(ORIGINALS[f])

shutil.copy2(HERE / "pipeline_state.py", ROOT / "pipeline_state.py")
plan = ([] if has_checkpoints else ["db_patch.py", "main_patch.py"]) + ["memory_patch.py"]
print("Plan:", " -> ".join(plan))
try:
    for patch in plan:
        try:
            runpy.run_path(str(HERE / patch), run_name="__main__")
        except SystemExit as e:                      # the patch scripts use SystemExit for "already patched"
            if e.code not in (None, 0):
                raise
    for f in TOUCHED:
        py_compile.compile(str(ROOT / f), doraise=True)
except BaseException as e:                           # noqa: BLE001 - restore on ANY failure
    for f, data in ORIGINALS.items():
        if data is None:
            (ROOT / f).unlink(missing_ok=True)
        else:
            (ROOT / f).write_bytes(data)
    sys.exit(f"\nINSTALL FAILED - originals restored, nothing changed.\nReason: {type(e).__name__}: {e}")

print("\nInstalled. Restart the app:  pkill -f 'main\\.py'; bash start.sh")
